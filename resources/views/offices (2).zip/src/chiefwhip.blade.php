@extends('layouts.master')

<title>AAUASU Chief Whip</title>
@section('content')
    <h1 class="white"><b><span><img src="/images/aauasufist.png" alt="" height="100">Office of the Chief Whip</span></b></h1>
    <hr>
@endsection
