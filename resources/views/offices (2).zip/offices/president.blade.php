@extends('layouts.master')  

<title>AAUASU President</title>
@section('content')
<h1 class="white"><b><span><img src="/images/aauasufist.png" alt="" height="100">Office of the President</span></b></h1>
<hr>

<div class="container text-center">
  <div class="row">


    <div class="container">
        <div class="row">
          <div class="col-sm-3">
            <div class="panel panel-primary">
              <div class="panel-heading"><strong>President</strong></div>
              <div class="panel-body"><img src="images/face4.png" class="img-responsive" alt="Image"></div>
              <div class="panel-footer"><strong>Ijanusi Olawale <i>(Optimum)</i></strong></div>
            </div>
          </div>
        </div>
    </div>
  </div>
</div>


@endsection