@extends('layouts.master')
<div class="white">
    <title>AAUASU Treasurer</title>
@section('content')
        <h1 class="white"><b><span><img src="/images/aauasufist.png" alt="" height="100">Office of the Treasurer</span></b></h1>
        <hr>


        <div class="white">
            <p>The students union of Adekunle Ajasin University Akungba Akoko Ondo State, Nigeria</p>
        </div>
        <div class="row">
            <div class="media col col-md-12">
                <div class="col col-md-3" style="border: solid 5px mediumpurple; padding: 1px; border-radius: 10px 10px 0 0;">
                    <img src="/images/sec/006.jpg" style="width:200px">
                </div>
            </div>
        </div>
</div>
@endsection
