@extends('layouts.master')  

<title>SUB Palava</title>
@section('content')
<h2>Gists From The Building</h2>

  <div class="div">
   <p>The students union of Adekunle Ajasin University Akungba Akoko Ondo State, Nigeria</p>
  </div>

@endsection