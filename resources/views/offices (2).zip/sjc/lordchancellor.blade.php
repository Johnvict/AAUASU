@extends('layouts.master')

<title>AAUASU Lord Chancellor</title>
@section('content')

    <h1 class="white"><b><span><img src="/images/aauasufist.png" alt="" height="100">Office of the Lord Chancellor</span></b></h1>
    <hr>
@endsection
