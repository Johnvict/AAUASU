<?php

use Faker\Generator as Faker;

$factory->define(App\Aauaites::class, function (Faker $faker) {
    return [
        //
    ];
});
