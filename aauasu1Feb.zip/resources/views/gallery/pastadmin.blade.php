@extends('layouts.master')  

<title>Past Administration</title>
@section('content')
<h2>Past Administrations</h2>

  <div class="div">
   <p>Past Administration of the Students Union</p>
  </div>

@endsection