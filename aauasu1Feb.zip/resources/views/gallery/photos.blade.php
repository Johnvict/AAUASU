@extends('layouts.master')  

<title>Photo Albums</title>
@section('content')
<h2>Photo Album</h2>

  <div class="div">
   <p>Photos of the Students Union</p>
  </div>

@endsection