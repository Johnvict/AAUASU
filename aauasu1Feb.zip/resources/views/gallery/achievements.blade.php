@extends('layouts.master')  

<title>Achievements</title>
@section('content')
<h2>Achievements</h2>

  <div class="div">
   <p>Achievements of the present administration of the Students Union</p>
  </div>

@endsection