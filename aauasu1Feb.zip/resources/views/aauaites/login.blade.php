@extends('layouts.master')  

<title>Signup New User</title>
@section('content')

@endsection