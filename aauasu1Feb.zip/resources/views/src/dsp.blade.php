@extends('layouts.master')

<title>AAUASU Deputy SP</title>
@section('content')
    <h1 class="white"><b><span><img src="/images/aauasufist.png" alt="" height="100">Office of the Deputy Senate President</span></b></h1>
    <hr>
@endsection
