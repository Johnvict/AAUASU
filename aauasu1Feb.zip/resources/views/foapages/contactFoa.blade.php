@extends('layouts.foamaster')

<title>Contact FOA</title>
@section('content')

@endsection