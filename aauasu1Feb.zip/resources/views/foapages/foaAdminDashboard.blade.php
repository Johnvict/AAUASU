@extends('layouts.foaadminmaster')  

<title>FOA Admin Login Page</title>
@section('content')
    You're Welcome
@endsection