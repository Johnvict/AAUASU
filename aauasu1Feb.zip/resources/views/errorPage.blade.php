@extends('layouts.master')

<title>Error</title>
@section('content')
    <div class="row">
        <div class="col col-md-12">
            <div class="alert alert-danger text-center">
                <h2>Error!<br>Can't Process Request. Please go to our
                    <a style="text-decoration:none; text-size: 2em; font-weight: bold; color: purple;" href="/">Homepage Here</a></h2>
            </div>
        </div>
    </div>

@endsection