@extends('layouts.aauaites')

<title>AAUASU - My Academics</title>
@section('content')
    <h1 class="white"><b><span><img src="/images/aauasufist.png" alt="" height="100">My Academics</span></b></h1>
    <hr>
    <style>
        a:hover{
            text-decoration:none;
        }
    </style>

@endsection