@extends('layouts.master')  

<title>AAUASU Welfare Director</title>
@section('content')

<h1 class="white"><b><span><img src="/images/aauasufist.png" alt="" height="100">Office of the Director of Welfare</span></b></h1>
<hr>

  <div class="white">
   <p>The students union of Adekunle Ajasin University Akungba Akoko Ondo State, Nigeria</p>
  </div>

@endsection