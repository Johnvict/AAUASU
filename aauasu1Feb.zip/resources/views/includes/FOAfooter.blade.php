<style>
  .footer {
    border: solid 1px black;
    background: black;
    text-align: center;
    font-family: Raleway, "Helvetica Neue",Helvetica,Arial,sans-serif;
    font-weight: bold;
    color: white;
    border-radius: 10px 10px 0 0;
    margin-bottom: 5px;
    opacity: .9;
  }
</style>
            <hr>
            <div class="footer">
              <footer>
                  <form class="form-inline"></strong> Johnvict Was here:
                    <p>
                  </form>
                  <p>&copy {{date('Y')}} AAUA students' Union</p>
                  <p>Designed by <img src="/images/thePrime.png"></b>: 08108307073</p>
              </footer>
            </div>
        