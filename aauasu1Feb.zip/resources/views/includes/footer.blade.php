<style>
    .footerContainer{
        margin-top: 10%;
        border: 1px solid white;
        border-radius: 15px 15px 0 0;
        padding: 5px 0 0 0;
        width: 100%;
        text-align: center;
        font-family: "Lucida Handwriting",forte, Raleway, "Helvetica Neue",Helvetica,Arial,sans-serif;
        color: white;
        background: black;
        opacity: .9;
    }
</style>


    <footer class="footerContainer text-center">
        <p>&copy {{date('Y')}} Adekunle Ajasin University Akungba Students Union<br>
        Designed by <img src="/images/thePrime.png"></b>: 08108307073</p>
    </footer>
