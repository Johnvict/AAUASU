@extends('layouts.aauaites')
<title>Admin - Material Uploads</title>
@section('titleHere')
    Admin Dashboard
@endsection

@section('content')


@endsection