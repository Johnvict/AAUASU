<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Buddy extends Model
{
    //
}
