<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Facades\Session;
use App\nick;


class nickController extends Controller
{
    //
}
