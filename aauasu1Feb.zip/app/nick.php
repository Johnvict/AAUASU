<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class nick extends Model
{
    //
}
