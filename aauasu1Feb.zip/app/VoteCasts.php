<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VoteCasts extends Model
{
    //
}
