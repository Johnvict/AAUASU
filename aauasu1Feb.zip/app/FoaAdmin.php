<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FoaAdmin extends Model
{
    //
}
