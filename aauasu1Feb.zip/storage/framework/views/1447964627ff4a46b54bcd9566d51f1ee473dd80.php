  

<title>Achievements</title>
<?php $__env->startSection('content'); ?>
<h2>Achievements</h2>

  <div class="div">
   <p>Achievements of the present administration of the Students Union</p>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>