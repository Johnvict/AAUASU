<title>AAUASU - My Courses</title>
<?php $__env->startSection('titleHere'); ?>
    My Courses
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
                <div class="col col-md-12 alert alert-info">
                    <?php if(session('course')): ?>
                        <p>A New Course Added Successfully</p>
                    <?php endif; ?>
                    <b>Click Buttons below to see Courses Added</b>
                </div>
                <div class="col col-md-6">
                    
                    <div>
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#Modal100"><b>100 Level Courses</b></button>

                        <!-- Modal -->
                        <div class="modal fade" id="Modal100" role="dialog">
                            <div class="modal-dialog">

                                <!-- Modal content-->
                                <?php echo $__env->make('academics.course100', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            </div>
                        </div>
                    </div><br>

                    
                    <div>
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#Modal200"><b>200 Level Courses</b></button>

                        <!-- Modal -->
                        <div class="modal fade" id="Modal200" role="dialog">
                            <div class="modal-dialog">

                                <!-- Modal content-->
                                <?php echo $__env->make('academics.course200', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col col-md-6">
                    
                    <div>
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#Modal300"><b>300 Level Courses</b></button>

                        <!-- Modal -->
                        <div class="modal fade" id="Modal300" role="dialog">
                            <div class="modal-dialog">

                                <!-- Modal content-->
                                <?php echo $__env->make('academics.course300', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            </div>
                        </div>
                    </div><br>

                    
                    <div>
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#Modal400"><b>400 Level Courses</b></button>

                        <!-- Modal -->
                        <div class="modal fade" id="Modal400" role="dialog">
                            <div class="modal-dialog">

                                <!-- Modal content-->
                                <?php echo $__env->make('academics.course400', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                            </div>
                        </div>
                    </div>
                </div>

                
                <div>
                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#Modal500"><b>500 Level Courses</b></button>

                    <!-- Modal -->
                    <div class="modal fade" id="Modal500" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
                            <?php echo $__env->make('academics.course500', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        </div>
                    </div>
                </div><br><br>

                <div class="row">
                    <div class="col-sm-12 alert alert-info">

                        <div class="panel panel-default text-left">
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col col-md-6">
                                        <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addCourseModal"><b>ADD A NEW COURSE</b></button>
                                    </div>

                                    <?php if(count($myCourses) > 0): ?>
                                        <div class="col col-md-6">
                                            <form action="<?php echo e(route('gpaPopulate')); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-success btn-sm col-md-offset-7"><b>POPULATE GPA</b></button>
                                            </form>
                                        </div>
                                    <?php else: ?>
                                    <?php endif; ?>
                                </div>

                                <!-- Modal For Course Adding-->
                                <div class="modal fade" id="addCourseModal" role="dialog">
                                    <div class="modal-dialog">

                                        <!-- Modal content-->
                                        <div class="modal-content">
                                            <div class="modal-header alert alert-info">

                                                <h4 class="modal-title"><b>ADD A NEW COURSE</b></h4>
                                            </div>
                                            <div class="modal-body">
                                                <form method="POST" action="<?php echo e(url('/my-courses/'.Auth::User()->id)); ?>">
                                                    <?php echo e(csrf_field()); ?>

                                                    <div class="col col-md-6">
                                                        <div class="form-group">
                                                            <label for="courseCode">Course Code</label>
                                                            <input id="courseCode" type="text" name="courseCode" placeholder="CSC 419" class="form-control" required autofocus>
                                                            <?php if($errors->has('courseCode')): ?>
                                                                <span class="help-block"><strong><?php echo e($errors->first('courseCode')); ?></strong></span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="dept">Course Unit:</label>
                                                            <input type="number" name="courseUnit" placeholder="Course Unit" class="form-control" required autofocus>
                                                            <?php if($errors->has('courseUnit')): ?>
                                                                <span class="help-block"><strong><?php echo e($errors->first('courseUnit')); ?></strong></span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="courseGrade">Grade (choose N/A for not available)</label>
                                                            <select name="courseGrade" class="form-control" required autofocus>
                                                                <option value="">Grade</option>
                                                                <option value="NA">N/A</option>
                                                                <option value="A">A</option>
                                                                <option value="B">B</option>
                                                                <option value="C">C</option>
                                                                <option value="D">D</option>
                                                                <option value="E">E</option>
                                                                <option value="F">F</option>
                                                            </select>
                                                            <?php if($errors->has('courseCode')): ?>
                                                                <span class="help-block"><strong><?php echo e($errors->first('courseCode')); ?></strong></span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                    <div class="col col-md-6">
                                                        <div class="form-group">
                                                            <label for="dept">Course Level</label>
                                                            <select name="courseLevel" class="form-control" required autofocus>
                                                                <option value="">Level</option>
                                                                <option value="100">100</option>
                                                                <option value="200">200</option>
                                                                <option value="300">300</option>
                                                                <option value="400">400</option>
                                                                <option value="500">500</option>
                                                            </select>
                                                            <?php if($errors->has('courseCode')): ?>
                                                                <span class="help-block"><strong><?php echo e($errors->first('courseCode')); ?></strong></span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="dept">Course Semester</label>
                                                            <select name="courseSemester" class="form-control" required autofocus>
                                                                <option value="">Semester</option>
                                                                <option value="1">1st</option>
                                                                <option value="2">2nd</option>
                                                            </select>
                                                            <?php if($errors->has('courseCode')): ?>
                                                                <span class="help-block"><strong><?php echo e($errors->first('courseCode')); ?></strong></span>
                                                            <?php endif; ?>
                                                        </div><br>
                                                    </div>
                                                    <button type="submit" class="btn btn-primary col-md-offset-2">Add Course</button>
                                                </form>
                                            </div>
                                            <div class="modal-footer alert-info">
                                                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                        </div>
                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aauaites', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>