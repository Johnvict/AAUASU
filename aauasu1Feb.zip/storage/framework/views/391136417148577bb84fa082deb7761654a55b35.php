<title>Status</title>
<?php $__env->startSection('titleHere'); ?>
    Status
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(auth()->guard()->guest()): ?>

<?php else: ?>
    <div class="row">
        <section class="ro w">
            <div class="media col col-md-12">
                <div class="media-left">
                    <?php if($post->user->Avatar == 'AvatarDefault'.$post->user->Gender.'.jpg'): ?>
                        <a href="/profile/<?php echo e($post->user->Username); ?>"><img class="profile-img col-offset-5" src="/avatar/<?php echo e($post->user->Avatar); ?>" style="width:70px"></a>
                    <?php else: ?>
                        <a href="/profile/<?php echo e($post->user->Username); ?>"><img class="profile-img col-offset-5" src="<?php echo e($post->user->Avatar); ?>" style="width:70px"></a>
                    <?php endif; ?>
                    <div class="white"><b><?php echo e($post->user->Username); ?></b></div>
                </div>
                <div class="media-body">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <a href="/profile/<?php echo e($post->user->Username); ?>"><h4 class="media-heading"><b><?php echo e($post->user->Name); ?></b></h4></a>
                        </div>
                        <div class="panel-body">
                        <span class="pull-right">
                            <i><?php echo e($post->created_at->diffForHumans()); ?></i>
                        </span><br>
                            <p style="text-align: justify; font-weight: bold; font-size: .9em;"><?php echo $post->content; ?><br><hr></p>
                            <a href='<?php echo url('foa'); ?>' class="btn btn-primary btn-sm"><span class="glyphicon glyphicon-thumbs-up"></span> Like</a> |
                            <a href='<?php echo url('foa'); ?>' class="btn btn-warning btn-sm"><span class="glyphicon glyphicon-thumbs-down"></span> Dislike</a>
                            <?php if(Auth::User() == $post->User): ?>
                                |
                                <a href="/edit/<?php echo e($post->id); ?>" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-edit"></span> Edit</a> |
                            <?php endif; ?>
                            <?php if(Auth::user()->is_admin == "1" OR Auth::User() == $post->User): ?>
                                <a href=/delete/<?php echo e($post->id); ?>" class="btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                            <?php endif; ?>
                        </div>


                    </div>
                </div>
            </div>
        </section>

        <div>
            <?php if(count($comments)>0): ?>
                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($comment->postUpdate_id == $post->id): ?>
                        <section class="row">
                            <div class="media col col-md-12">
                                <div class="media col col-md-12">
                                    <div class="media-body">
                                        <div class="panel panel-primary">
                                            <div class="media-center">
                                                <div style="text-align: justify; font-size: .9em; padding: 2%;">
                                                <span class="pull-right">
                                                    <i><?php echo e($comment->created_at->diffForHumans()); ?></i>
                                                </span><br>
                                                    <p><?php echo e($comment->body); ?></p>
                                                    <div class="alert alert-info">
                                                        <?php if($comment->user->Avatar == 'AvatarDefault'.$comment->user->Gender.'.jpg'): ?>
                                                            <a href="/profile/<?php echo e($comment->user->Username); ?>"><img class="profile-img col-offset-5" src="/avatar/<?php echo e($comment->user->Avatar); ?>" style="width:40px"></a>
                                                        <?php else: ?>
                                                            <a href="/profile/<?php echo e($comment->user->Username); ?>"><img class="profile-img col-offset-5" src="<?php echo e($comment->user->Avatar); ?>" style="width:40px"></a>
                                                        <?php endif; ?>
                                                        <b><a href="/profile/<?php echo e($comment->user->Username); ?>"><?php echo e($comment->user->Username); ?></a>| </b>
                                                        <a href='<?php echo url('foa'); ?>'><span class="glyphicon glyphicon-thumbs-up"></span> Like</a>
                                                        <?php if(Auth::user()== $post->user): ?>
                                                            |
                                                            <a href="/deleteComment/<?php echo e($comment->id); ?>"><span class="glyphicon glyphicon-trash"></span> Delete</a>
                                                            <?php if(Auth::User() == $comment->user): ?>
                                                                |
                                                                <a href="/editComment/<?php echo e($comment->id); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a>
                                                            <?php endif; ?>
                                                        <?php elseif(Auth::User() == $comment->user): ?>
                                                            |
                                                            <a href="/editComment/<?php echo e($comment->id); ?>"><span class="glyphicon glyphicon-edit"></span> Edit</a>
                                                        <?php endif; ?>
                                                        <?php if(Auth::user() == $comment->user OR Auth::user()->is_admin == "1"): ?>
                                                            |
                                                            <a href='/deleteComment/<?php echo e($comment->id); ?>'><span class="glyphicon glyphicon-trash"></span> Delete</a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="panel panel-default text-left">
            <div class="panel-body">
                <form method="POST" action="<?php echo e(route('commentPost')); ?>">
                    <?php echo e(csrf_field()); ?>


                    <div class="form-group">
                        <label for="content">Comment on this post</label>
                        <textarea id="postIntended" type="text" name="content" class="form-control" placeholder="Write something" required autofocus></textarea>

                        <?php if($errors->has('postIntended')): ?>
                            <span class="help-block"><strong><?php echo e($errors->first('postIntended')); ?></strong></span>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                    <button type="submit" class="btn btn-primary btn-sm pull-right">Post Comment</button>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aauaites', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>