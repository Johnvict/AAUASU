<title>Admin - News Page</title>
<?php $__env->startSection('titleHere'); ?>
    Admin - News
<?php $__env->stopSection(); ?>


<style>
    .panel {
        -webkit-box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        color: black;
    }
    .panel-news > .panel-heading {
        background-image: -webkit-linear-gradient(top, black 0%, white 100%);
        background-image: linear-gradient(to bottom, black 0%, black 100%);
        background-repeat: repeat-x;
        color:white;
        filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='black', endColorstr='black', GradientType=0);
    }
</style>

<?php $__env->startSection('content'); ?>
    <?php if(session('success') != null): ?>
        <div class="alert alert-success">
            <span class="badge"><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default text-left">
                <div class="panel-body">
                    <form method="POST" action="<?php echo e(route('createNews')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group">
                            <label for="content">News Headline</label>
                            <input type="text" class="form-control" name="title" placeholder="add news headline..">
                            <?php if($errors->has('title')): ?>
                                <span class="help-block">
                              <strong><?php echo e($errors->first('title')); ?></strong>
                          </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="content">News Content</label>
                            <textarea id="article-ckeditor" type="text" name="body" class="form-control" style="width:100%;height:200px;" placeholder="Write news here.."></textarea>
                            <?php if($errors->has('body')): ?>
                                <span class="help-block">
                              <strong><?php echo e($errors->first('body')); ?></strong>
                          </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group text-center">
                            <label for="content">Show News To Users?</label><br>
                            <input type="radio" checked="checked" name="show" value="1">Show Now</b>
                            </input><br>
                            <input type="radio" name="show" value="0">Hide</b>
                            </input>
                        </div>

                        <button type="submit" class="btn btn-success pull-right">Post News</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <?php if(count($news) > 0): ?>
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="panel panel-news">

                <div class="panel-heading">
                    <b><h3><?php echo e($new->title); ?></h3></b>
                    <b><h6>Posted On: <?php echo e($new->created_at); ?>: <?php echo e($new->created_at->diffForHumans()); ?></h6></b>
                    <b><h6>Edited On: <?php echo e($new->updated_at); ?>: <?php echo e($new->updated_at->diffForHumans()); ?></h6></b>

                </div>
                <div class="panel-body">
                    <p style="text-align:justify; font-family: calibri;"><?php echo $new->body; ?></p>
                    <div class="btn-group pull-right">
                        <button type="button" class="btn btn-success btn-sm" data-toggle="modal"
                                data-target="#edit<?php echo e($new->id); ?>"><span class="glyphicon glyphicon-edit"> Edit</span></button>
                        <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                data-target="#delete<?php echo e($new->id); ?>"><span class="glyphicon glyphicon-trash"> Delete</span></button>
                    </div>
                </div>
            </div>

            <!-- Edit Modal -->
            <div class="modal fade" id="edit<?php echo e($new->id); ?>" role="dialog">
                <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header alert ">
                            <h4 class="modal-title"><b><?php echo e($new->title); ?></b></h4>
                        </div>
                        <div class="modal-body">
                            <form method="POST" action="<?php echo e(route('editNews')); ?>">
                                <?php echo e(csrf_field()); ?>


                                <input type="hidden" name="newsId" value="<?php echo e($new->id); ?>"/>

                                <div class="form-group">
                                    <label for="content">News Headline</label>
                                    <input type="text" class="form-control" name="title" value="<?php echo e($new->title); ?>">
                                    <?php if($errors->has('title')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('title')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="content">News Content</label>
                                    <textarea id="article-ckeditor" type="text" name="body" class="form-control" style="width:100%;height:200px;" value="<?php echo $new->body; ?>"><?php echo e($new->body); ?>"</textarea>
                                    <?php if($errors->has('body')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('body')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label for="content">Show News To Users?</label><br>
                                    <input type="radio" <?php if($new->show_status == "1"): ?> checked="checked" <?php endif; ?> name="show" value="1">
                                        <b><?php if($new->show_status == "1"): ?> Shown <?php else: ?> Show Now <?php endif; ?></b>
                                    </input><br>
                                    <input type="radio" <?php if($new->show_status == "0"): ?> checked= "checked" <?php endif; ?> name="show" value="0">
                                        <b> <?php if($new->show_status == "0"): ?> Hidden <?php else: ?> Hide Now <?php endif; ?></b>
                                    </input>
                                </div>
                                <div class="btn-group pull-right">
                                    <button type="submit" class="btn btn-success btn-xs"><b>Save Changes</b></button>
                                    <button type="button" class="btn btn-default btn-xs disabled"><b>Check Please</b></button>
                                    <button type="button" class="btn btn-danger btn-xs" data-dismiss="modal"><b>Cancel Changes</b></button>
                                </div><br>
                            </form>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Delete Modal -->
            <div class="modal fade" id="delete<?php echo e($new->id); ?>" role="dialog">
                <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header alert ">
                            <h4 class="modal-title"><b><?php echo e($new->title); ?></b></h4>
                        </div>
                        <div class="modal-body">
                            <form method="POST" action="<?php echo e(route('editNews')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php echo $new->fewerBody; ?>

                                <p style="color:#ff0000; font-family: 'Incised901 Nd Bt';" ><b>Delete News?</b></p>
                                <div class="btn-group pull-right">
                                    <a href="/delete-news/<?php echo e($new->id); ?>/" class="btn btn-danger btn-xs"><b>Delete</b></a>
                                    <button type="button" class="btn btn-default btn-xs disabled"><b>Check Please</b></button>
                                    <button type="button" class="btn btn-success btn-xs" data-dismiss="modal"><b>Cancel</b></button>
                                </div><br>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <?php else: ?>
        <div class="alert alert-success">
            <p>No News added yet</p>
        </div>
    <?php endif; ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aauaites', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>