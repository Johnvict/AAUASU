<title>AAUAITES - Home</title>
<?php $__env->startSection('titleHere'); ?>
    Students Area
<?php $__env->stopSection(); ?>

<?php $__env->startSection('userPix'); ?>
    <img class="imag col-md-offset-5" src="<?php echo e(Auth::user()->Avatar); ?>"alt="" height="100">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    
<style>
    /* Set black background color, white text and some padding */
    footer {
      background-color: #555;
      color: white;
      padding: 15px;
    }
      a:hover{
          text-decoration:none;
      }
    .profile-img {
        max-width: 200px;
        border: 5px solid #fff;
        border-radius: 75%;
        box-shadow: 0 2px 2px rgba(0, 0, 0, 0.3);
    }
      .white{
          color: white;
      }
  </style>

      <div class="row">
        <div class="col-sm-12">
          <div class="panel panel-default text-left">
            <div class="panel-body">
              <form method="POST" action="<?php echo e(route('store')); ?>">
                  <?php echo e(csrf_field()); ?>


                  <div class="form-group">

                      <?php if(session('message') != null): ?>
                        <p class="alert alert-success size"> <?php echo e(session('message')); ?> </p>
                      <?php endif; ?>
                      <label for="content">Update Status</label>
                      <textarea <?php if(Auth::user()->is_admin == "1"): ?>id="article-ckeditor" <?php endif; ?> type="text" name="content" class="form-control" placeholder="Write something"></textarea>
                        <?php if($errors->has('postIntended')): ?>
                          <span class="help-block">
                              <strong><?php echo e($errors->first('postIntended')); ?></strong>
                          </span>
                        <?php endif; ?>
                  </div>
                  <button type="submit" class="btn btn-success pull-right">Post Status</button>
              </form>
            </div>
          </div>
        </div>
      </div>

    
    <?php if(count($allStatuss)>0): ?>
        <?php $__currentLoopData = $allStatuss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('aauaites.statuses', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>




  <script>
      var token = '<?php echo e(Session::token()); ?>';
      var urlLike = '<?php echo e(route('like')); ?>';
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aauaites', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>