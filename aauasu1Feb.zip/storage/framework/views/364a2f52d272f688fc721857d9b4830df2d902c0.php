<title>AAUASU Senate President</title>
<?php $__env->startSection('content'); ?>
    <h1 class="white"><b><span><img src="/images/aauasufist.png" alt="" height="100">Office of the Senate President</span></b></h1>
    <hr>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>