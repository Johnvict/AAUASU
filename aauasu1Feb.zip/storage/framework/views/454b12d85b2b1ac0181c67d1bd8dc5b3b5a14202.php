<div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title"><b>200 LEVEL COURSES</b></h4>
    </div>
    <div class="modal-body alert alert-info">
        <?php $thisCount = 0 ?>
        <?php $__currentLoopData = $myCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($myCourse->level == 200): ?>
                <?php $thisCount = $thisCount + 1 ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($thisCount>0): ?>
            <div class="">
                <table class="table modal-body">
                    <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Code</th>
                        <th>Unit</th>
                        <th>Grade</th>
                        <th>Remove Course</th>
                        <th>Update Grade</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $sn = 0 ?>
                    <?php $__currentLoopData = $myCourses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myCourse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($myCourse->level == 200): ?>
                            <?php $sn++ ?>
                            <tr>

                                <th class=""><b><?php echo e($sn); ?></b></th>
                                <td class=""><b><?php echo e($myCourse -> code); ?></b></td>
                                <td class=""><b><?php echo e($myCourse->unit); ?></b></td>
                                <td class=""><b><?php echo e($myCourse -> grade); ?></b></td>

                                <td class="">
                                    <button type="button" class="label label-danger" data-toggle="modal" data-target="#remove<?php echo e($myCourse->id); ?>">Remove Course</button>

                                    <!-- Remove Modal -->
                                    <div class="modal fade" id="remove<?php echo e($myCourse->id); ?>" role="dialog">
                                        <div class="modal-dialog">
                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header alert alert-danger">
                                                    <h4 class="modal-title"><b>Remove <?php echo e($myCourse-> code); ?></b></h4>
                                                </div>
                                                <div class="modal-body">
                                                    <p class="text-center">Are you sure you want to remove <?php echo e($myCourse->code); ?> from <?php echo e($myCourse->level); ?> level courses?
                                                        <b>You can add it later anyway</b></p>
                                                </div>
                                                <div class="modal-footer">
                                                    <a href="/removeCourse/<?php echo e($myCourse -> id); ?>" class="btn btn-danger">Remove Course</a>
                                                    <button type="button" class="btn btn-success btn-group-lg" data-dismiss="modal"><b>No</b></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="">
                                    <a href="#updateGrade<?php echo e($myCourse->id); ?>" class="label label-success" data-toggle="collapse"><b>Update Grade</b></a>
                                    <div id="updateGrade<?php echo e($myCourse->id); ?>" class="collapse">
                                        <form method="post" action="/updateGrade/<?php echo e($myCourse -> id); ?>" enctype="multipart/form-data">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="row">
                                                <div class="col col-md-1">
                                                    <div class="form-group">
                                                        <select name="courseGrade" class="form-control" required autofocus>
                                                            <option value="">N/A</option>
                                                            <option value="A">A</option>
                                                            <option value="B">B</option>
                                                            <option value="C">C</option>
                                                            <option value="D">D</option>
                                                            <option value="E">E</option>
                                                            <option value="F">F</option>
                                                        </select>
                                                        <?php if($errors->has('courseCode')): ?>
                                                            <span class="help-block"><strong><?php echo e($errors->first('courseCode')); ?></strong></span>
                                                        <?php endif; ?>
                                                    </div>
                                                    <button type="submit" class="label label-primary">Save</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    </tr>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-warning">
                <b>No COURSES found for this semester</b>
            </div>
        <?php endif; ?>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
</div>