<?php $__env->startSection('titleHere'); ?>
     <?php echo e($user->Name); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

       

<style type="text/css">
	.profile-img {
		max-width: 200px;
		border: 5px solid #fff;
		border-radius: 100%; //For a round-shaped image
		box-shadow: 0 2px 2px rgba(0, 0, 0, 0.3);
	}
	.smallbody{
		border: 2px solid gray;
		background: white;
		border-radius: 20px;
	}
</style>

   <img class="profile-img col-offset-5" src="<?php echo e($user->Avatar); ?>"><br><br>

<?php if($user->is_admin == "1"): ?>
    <div class="panel panel-primary">
        <div class="panel-head">
            <h3 style="font-family: forte;"><?php echo e($user->Username); ?> </h3>
        </div>
        <h4><b>Contact: <?php echo e($user->PhoneNumber); ?></b></h4>
    </div>


<?php else: ?>
    <div class="panel panel-primary">
        <h3 style="font-family: forte;">Name: <?php echo e($user->Name); ?> </h3>
        <h4><b>Username: <?php echo e($user->Username); ?> </b></h4>
        <h4><b>Gender: <?php echo e($user->Gender); ?> </b></h4>
        <h4><b>Phone Number: <?php echo e($user->PhoneNumber); ?></b></h4>
    </div>
    <?php if(auth()->guard()->guest()): ?>
    <?php else: ?>
        <div class="panel panelsuccess">

            <?php if(Auth::User()->id == $user->id): ?>
                <h4>Matric. Number: <?php echo e($user->MatricNumber); ?> </h4>
            <?php endif; ?>
            <h4>Email: <?php echo e($user->Email); ?> </h4>

            <h4>Faculty: <?php echo e($user->Faculty); ?> </h4>
            <h4>Department: <?php echo e($user->Department); ?> </h4>
            <h4>Level: <?php echo e($user->Level); ?> </h4>
            <h4>About: <?php echo e($user->About); ?> </h4>
            <h4>Post Held: <?php echo e($user->PostHeld); ?> </h4>
        </div>

        <?php if(Auth::User()->id == $user->id): ?>
            <a href="/editprofile/<?php echo e($user->MatricNumber); ?>" class="btn btn-primary">Edit Profile</a>
        <?php else: ?>
            <button class="btn btn-success">Follow</button>
        <?php endif; ?>
        <?php endif; ?>
<?php endif; ?>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aauaites', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>