<title>AAUASU - My Grade Point</title>

<?php $__env->startSection('titleHere'); ?>
    My Grade Points
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(count($myGpa)>0): ?>

        <?php if($myGpa->finalCGPA == 0.01): ?>
            <div class="alert alert-warning">
                <b>Yo Have Not Added Any Academic Records Yet</b><br><hr>
                <a href="/my-courses/"><button type="button" class="btn btn-primary btn-xl"><b class="white">Add Your Courses & Results Here</b></button></a>
            <hr></div>
        <?php else: ?>
            <div class="col col-md-6">
                <div>
                    <div class="btn btn-info btn-sm"><b>100 Level 1st Semester GPA: <?php if($myGpa->gpa1001 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->gpa1001); ?> <?php endif; ?> </b></div><br>
                    <div class="btn btn-success btn-sm"><b>100 Level 2nd Semester GPA: <?php if($myGpa->gpa1002 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->gpa1002); ?> <?php endif; ?> </b></div><br>
                    <div class="btn btn-default btn-sm"> <b>100 Level CGPA: <?php if($myGpa->cgpa100 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->cgpa100); ?> <?php endif; ?></b></div><br>
                </div><br>

                <div>
                    <div class="btn btn-warning btn-sm"> <b>200 Level 1st Semester GPA: <?php if($myGpa->gpa2001 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->gpa2001); ?> <?php endif; ?></b></div><br>
                    <div class="btn btn-danger btn-sm"> <b>200 Level 2nd Semester GPA: <?php if($myGpa->gpa2002 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->gpa2002); ?> <?php endif; ?></b></div><br>
                    <div class="btn btn-default btn-sm"> <b>200 Level CGPA: <?php if($myGpa->cgpa200 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->cgpa200); ?> <?php endif; ?></b></div><br>
                </div>
            </div>

            <div class="col col-md-6">
                <div>
                    <div class="btn btn-info btn-sm"> <b>300 Level 1st Semester GPA: <?php if($myGpa->gpa3001 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->gpa3001); ?> <?php endif; ?></b></div><br>
                    <div class="btn btn-success btn-sm"> <b>300 Level 2nd Semester GPA: <?php if($myGpa->gpa3002 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->gpa3002); ?> <?php endif; ?></b></div><br>
                    <div class="btn btn-default btn-sm"> <b>300 Level CGPA: <?php if($myGpa->cgpa300 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->cgpa300); ?> <?php endif; ?></b></div><br>
                </div><br>

                <div>
                    <div class="btn btn-warning btn-sm"> <b>400 Level 1st Semester GPA: <?php if($myGpa->gpa4001 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->gpa4001); ?> <?php endif; ?></b></div><br>
                    <div class="btn btn-danger btn-sm"> <b>400 Level 2nd Semester GPA: <?php if($myGpa->gpa4002 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->gpa4002); ?> <?php endif; ?></b></div><br>
                    <div class="btn btn-default btn-sm"> <b>400 Level CGPA: <?php if($myGpa->cgpa400 == 0.01): ?>
                                Nill <?php else: ?> <?php echo e($myGpa->cgpa400); ?> <?php endif; ?></b></div><br>
                </div>
            </div>

            <div>
                <div class="btn btn-danger btn-sm"> <b>500 Level 1st Semester GPA: <?php if($myGpa->gpa5001 == 0.01): ?>
                            Nill <?php else: ?> <?php echo e($myGpa->gpa5001); ?> <?php endif; ?></b></div><br>
                <div class="btn btn-primary btn-sm"> <b>500 Level 2nd Semester GPA: <?php if($myGpa->gpa5002 == 0.01): ?>
                            Nill <?php else: ?> <?php echo e($myGpa->gpa5002); ?> <?php endif; ?></b></div><br>
                <div class="btn btn-default btn-sm"> <b>500 Level CGPA: <?php if($myGpa->cgpa500 == 0.01): ?>
                            Nill <?php else: ?> <?php echo e($myGpa->cgpa500); ?> <?php endif; ?></b></div><br>
            </div><br><br>

            <hr><div class="btn btn-primary btn-sm">
                <b>FINAL CGPA: <?php if($myGpa->finalCGPA == 0.01): ?>
                        No Academic Records Found <?php else: ?> <?php echo e($myGpa->finalCGPA); ?> <?php endif; ?></b><br>
            </div><hr>
            <div class="row">
                <div class="col-sm-12 alert alert-info">

                    <div class="panel panel-default text-left">
                        <div class="panel-body">
                            <form action="<?php echo e(route('gpaPopulate')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <button type="submit" class="btn btn-success btn-xl"><b>POPULATE (Update) GPA RECORD</b></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="alert alert-warning">
            <b>Yo Have Not Added Any Academic Records Yet</b><br><hr>
            <a href="/my-courses/"><button type="button" class="btn btn-primary btn-xl"><b class="white">Add Your Courses & Results Here</b></button></a>
            <hr></div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aauaites', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>