<title>AAUASU - Materials</title>

<?php $__env->startSection('titleHere'); ?>
    Materials
<?php $__env->stopSection(); ?>

<?php if(auth()->guard()->guest()): ?>
<?php else: ?>
    <?php $__env->startSection('userPix'); ?>
        <img class="imag col-md-offset-6" src="<?php echo e(Auth::user()->Avatar); ?>"alt="" height="100">
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <style>
        input[type="file"] {
            display: none;
        }
        .custom{
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: mediumseagreen;
            color: #ffffff;
            display: inline-block;
            padding: 6px 12px;
            cursor: pointer;
        }
    </style>

    <?php if(session('success') != null): ?>
        <div class="alert alert-success">
            <span class="badge"><?php echo e(session('success')); ?></span>
        </div>
    <?php elseif(session('error') != null): ?>
        <div class="alert alert-danger">
            <span class="badge"><?php echo e(session('error')); ?></span>
        </div>
    <?php endif; ?>
    <div class ="row">
            <div>
                <span class="badge badge-success"><h4>Upload File</h4></span>
                <br>
                <div class="thumbnail">
                    <p>Note: Admin will check if this file already exists or if it is relevant
                        for the use of AAUAITES<br>
                        We apologise for any inconviniencies this may cause you, <br>but you can be very sure
                        that it will soon be approved.
                    </p>
                    <form action="<?php echo e(route('uploadMaterial')); ?>" enctype="multipart/form-data" method="POST">
                        <?php echo e(csrf_field()); ?>


                        <label class="custom"><input type="file" name="material"/>Choose File</label>
                        <div class="form-group">
                            <label for="title">Add File Title</label>
                            <input type="text" name="title" class="form-control" placeholder="File Title"/>
                        </div>

                        <button type="submit" class="btn btn-default">Submit</button>
                    </form>
                </div>
            </div>
    </div>

    <?php if(count($appMaterials)>0): ?>
        <div class="row">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h4><b>Available Materials</b></h4>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                    <tr>
                        <th>S/N</th>
                        <th>Title</th>
                        <th>Size</th>
                        <th>Uploaded</th>
                        <th>Credits</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $sn = 1; ?>

                    <?php $__currentLoopData = $appMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appMat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $size = ($appMat->size)/1024;
                            if($size > 100)
                            {
                            $size = number_format($size/1024, 2);
                            $SIZE = $size."Mb";
                            }else{
                            $size = number_format($size, 2);
                            $SIZE = $size."Kb";
                            }
                        ?>
                        <tr style="color: black; font-weight: 400">
                            <td><?php echo e($sn); ?></td>
                            <td><img style="max-width: 30px; max-height: 30px" src="<?php echo e($appMat->icon); ?>">  <?php echo e($appMat->title); ?></td>
                            <td><?php echo e($SIZE); ?></td>
                            <td><?php echo e($appMat->created_at->diffForHumans()); ?></td>
                            <td>
                                <a href="/profile/<?php echo e($appMat->user->Username); ?>">
                                    <img class="profile-img col-offset-5" src="<?php echo e($appMat->user->Avatar); ?>" style="width:30px">
                                    <br><p style="color: black;"><?php echo e($appMat->user->Username); ?></p>
                                </a>
                            </td>
                            <td>
                                <a href="storage/materials/<?php echo e($appMat->name); ?>" download="<?php echo e($appMat->name); ?>" target="_blank">
                                <button class="btn btn-success btn-xs">Download</button>
                                </a>
                            </td>
                        </tr>
                    <?php $sn++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php else: ?>
        <div class="alert alert-warning">
            <p>No Material Available Yet</p>
        </div>
    <?php endif; ?>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aauaites', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>