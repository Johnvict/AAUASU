<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <title>AAUA Students Union Official Website</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/app.css')); ?>">


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>

<Style>
    .containerback {
        border: solid 2px black;
        padding: 5px;
        background: rgba(0, 0, 0, .5);
        border-radius: 10px;
        box-shadow: 2px 2px 2px rgba(4, 0, 0, 0.5);
    }
    body{
        background: url('/images/aauaback.jpg') no-repeat fixed center/cover;
        -webkit-background-size: 100%;
        -moz-background-size: 100%;
        -o-background-size: 100%;
        background-size: 100%;
    }
    .white{
        color: white;
    }
    .footerContainer{
        margin-top: 10%;
        border: 1px solid white;
        border-radius: 15px 15px 0 0;
        padding: 5px 0 0 0;
        width: 100%;
        text-align: center;
        font-family: "Lucida Handwriting",forte, Raleway, "Helvetica Neue",Helvetica,Arial,sans-serif;
        color: white;
        background: black;
        opacity: .9;
    }

</style>

<body>
    <?php echo $__env->make('includes.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="container">
            <div class="containerback">
                <?php echo $__env->yieldContent('content'); ?>
                <hr>
                <footer class="footerContainer text-center">
                    <p>&copy <?php echo e(date('Y')); ?> Adekunle Ajasin University Akungba Students Union<br>
                        Designed by <img src="/images/thePrime.png"></b> <span class="glyphicon glyphicon-phone-alt"> 08108307073</span></p>
                </footer>
            </div>
        </div>
    
    <div style="margin: 30px; "></div>
</body>

</html>
