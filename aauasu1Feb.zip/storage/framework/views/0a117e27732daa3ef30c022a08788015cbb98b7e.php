<title>Admin - Material Uploads</title>
<?php $__env->startSection('titleHere'); ?>
    Admin - Material Uploads
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <style>
        .icon{
            max-width: 80px;
            border: 5px solid #fff;
            border-radius: 10%;
            box-shadow: 0 2px 2px rgba(0, 0, 0, 0.3);
        }
    </style>


<?php $__env->startSection('content'); ?>
    <?php if(session('success') != null): ?>
        <div class="alert alert-success">
            <span class="badge"><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>
    <?php if(count($materials) > 0): ?>

            <div class="panel panel-primary">
                <div class="panel-heading"><b>Materials Awaiting Admin Approval</b></div>
                <div class="panel-body">


                    <table class="table table-hover table-strriped" style="font-size: 1em">
                        <thead>
                        <tr>
                            <th>Icon</th>
                            <th>Title</th>
                            <th>Uploader</th>
                            <th>Size</th>
                            <th>Time</th>
                            <th>Admin Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php
                                $size = ($mat->size)/1024;
                                if($size >= 1024)
                                {
                                $size = number_format($size/1024, 2);
                                $SIZE = $size."Mb";
                                }else{
                                $size = number_format($size, 2);
                                $SIZE = $size."Kb";
                                }
                                ?>
                            <td>
                                <div class="thumbnail">
                                    <a href="storage/materials/<?php echo e($mat->name); ?>" download="<?php echo e($mat->name); ?>" target="_b;lank">
                                        <img class="icon" src="<?php echo e($mat->icon); ?>" alt="<?php echo e($mat->type); ?>">
                                        <div class="figure-caption">
                                            <p><?php echo e($mat->type); ?></p>
                                        </div>
                                    </a>
                                </div>


                                <div class="caption"></div>
                            </td>
                            <td><?php echo e($mat->title); ?></td>
                            <td><?php echo e($mat->user->Username); ?></td>
                            <td><?php echo e($SIZE); ?></td>
                            <td><?php echo e($mat->created_at->diffForHumans()); ?></td>
                            <td>
                                <form action="<?php echo e(route('approve')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="approve" value="<?php echo e($mat->id); ?>">
                                    <button type="submit" class="btn btn-success btn-xs">Approve</button>
                                </form>
                                <form action="<?php echo e(route('disapprove')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="disapprove" value="<?php echo e($mat->id); ?>">
                                    <input type="hidden" name="filename" value="<?php echo e($mat->name); ?>">
                                    <button type="submit" class="btn btn-danger btn-xs">Disapprove</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

    <?php else: ?>
        <div class="alert alert-info">
            <h4><b>No Material Pending for Approval</b></h4>
        </div>
    <?php endif; ?>

    <?php if(count($appMaterials)>0): ?>
        <div class="row">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h4><b>Available Materials</b></h4>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Title</th>
                            <th>Size</th>
                            <th>Uploaded</th>
                            <th>Credits</th>
                            <th>Download</th>
                            <th>Delete</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $sn = 1; ?>
                        <?php $__currentLoopData = $appMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appMat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $size = ($appMat->size)/1024;
                            if($size > 100)
                            {
                            $size = number_format($size/1024, 2);
                            $SIZE = $size."Mb";
                            }else{
                            $size = number_format($size, 2);
                            $SIZE = $size."Kb";
                            }
                            ?>
                            <tr style="color: black; font-weight: 400">
                                <td><?php echo e($sn); ?></td>
                                <td><img style="max-width: 30px; max-height: 30px" src="<?php echo e($appMat->icon); ?>">  <?php echo e($appMat->title); ?></td>
                                <td><?php echo e($SIZE); ?></td>
                                <td><?php echo e($appMat->created_at->diffForHumans()); ?></td>
                                <td>
                                    <a href="/profile/<?php echo e($appMat->user->Username); ?>">
                                        <img class="profile-img col-offset-5" src="<?php echo e($appMat->user->Avatar); ?>" style="width:30px">
                                        <br><p style="color: black;"><?php echo e($appMat->user->Username); ?></p>
                                    </a>
                                </td>
                                <td>
                                    <a href="storage/materials/<?php echo e($appMat->name); ?>" download="<?php echo e($appMat->name); ?>" target="_blank">
                                        <button class="btn btn-success btn-xs">Download</button>
                                    </a>
                                </td>
                                <td>
                                    <form action="<?php echo e(route('disapprove')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="disapprove" value="<?php echo e($appMat->id); ?>">
                                        <input type="hidden" name="filename" value="<?php echo e($appMat->name); ?>">
                                        <button type="submit" class="btn btn-danger btn-xs">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php $sn++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">
            <p>No Material Available Yet</p>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aauaites', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>