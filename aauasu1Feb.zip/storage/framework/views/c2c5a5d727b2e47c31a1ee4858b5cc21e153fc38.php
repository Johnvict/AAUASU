<title>My Private Conversation</title>
<?php $__env->startSection('content'); ?>
    <style>
        a, a:active, a:hover {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
    </style>

    <div class="container">
        <div class="row">
            <div class="col col-md-6">
                <div class="row">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <button class="btn btn-primary btn-sm"><a href="<?php echo e(route('newPchat')); ?>">Start New Chat</a></button>
                            <button class="btn btn-warning btn-sm"><a href="<?php echo e(route('newPchat')); ?>">Back To Chat</a></button>
                        </div>
                        <div class="panel-body">
                            The Chat goes below
                            <?php if(session('messages') != null): ?>
                                <div class="alert alert-warning">
                                    <div cla ss="col col-md-6">
                                        <?php if(count($messages)>0): ?>
                                            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(Auth::User() == $message->User): ?>
                                                    <span class="glyphicon glyphicon-chat"><img src="/images/avatar/<?php echo e($message->user->Avatar); ?>" class="media-object" style="width:30px">
                                                    </span><article style="color: lawngreen; font-family: algerian; font-size: 1.2em; text-align: right;"><?php echo e($message->body); ?></article>
                                                <?php else: ?>
                                                    <span class="glyphicon glyphicon-chat"><img src="/images/avatar/<?php echo e($message->user->Avatar); ?>" class="media-object" style="width:30px">
                                                    </span><article style="color: deepskyblue; font-family: algerian; font-size: 1.2em; text-align: left;"><?php echo e($message->body); ?></article>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <div class="alert alert-warning">
                                                <p>Type a message below to start chating </p>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <form action="POST" action="<?php echo e(route('sendmessage')); ?>">
                                <?php echo e(csrf_field()); ?>


                                <div class="form-group">

                                    <input type="hidden" name="senderId" value="<?php echo e($authUserProfile->id); ?>">
                                    <input type="hidden" name="conversationId" value="<?php echo e($conversation->id); ?>">
                                    <label for="body">Write</label>
                                    <textarea id="body" type="text" name="body" class="form-control" placeholder="Type a message" required autofocus></textarea>
                                    <?php if($errors->has('postIntended')): ?>
                                        <span class="help-block"><strong><?php echo e($errors->first('body')); ?></strong></span>
                                    <?php endif; ?>
                                </div>
                                <button type="submit" class="btn btn-success pull-right">Send</button>
                            </form>

                        </div>
                    </div>

                </div>
            </div>
            <div class="col col-md-3">
                Thhis should be quick links or adverts
            </div>
            <div class="col col-md-3">
                Thhis should be quick links or adverts
                Thhis should be quick links or adverts
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aauaites', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>