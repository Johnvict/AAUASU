<title>Edit Post</title>

<?php $__env->startSection('titleHere'); ?>
    Edit Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <section class="ro w">
            <div class="media col col-md-12">
                <div class="media-body">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="panel-body">
                                <form method="POST" action="/update/<?php echo e($post->id); ?>">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group">
                                        <label for="content">Edit Post</label>
                                        <b><textarea style="color: green;"type="text" rows="10" value="<?php echo e($post->content); ?>" name="content" class="form-control" ><?php echo e($post->content); ?></textarea></b>

                                        <?php if($errors->has('postIntended')): ?>
                                            <span class="help-block"><strong><?php echo e($errors->first('postIntended')); ?></strong></span>
                                        <?php endif; ?>
                                    </div>
                                    <button type="submit" class="btn btn-success btn-sm pull-right"><b>Update Post</b></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.aauaites', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>