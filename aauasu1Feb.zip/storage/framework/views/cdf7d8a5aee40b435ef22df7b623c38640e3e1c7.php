<div class="container">
    <div class="row">
        <div class="col-sm-7">
            <h3>Simple CRUD App with Ajax</h3>
        </div>
        <div class="com-sm-5">
            <div class="pull-right">
                <div class="input-group">
                    <input type="text"
                           class="form-control"
                           value="<?php echo e(request()->session()->get('search')); ?>"
                           onkeydown="if (event.keyCode == 13) ajaxLoad('<?php echo e(url('posts')); ?>?search='+this.value)"
                           id="search"
                           name="search"
                           autofocus required
                           placeholder="Search title"/>
                    <div class="input-group-btn">
                        <button type="submit" name="button"
                                onclick="ajaxLoad('<?php echo e(url('posts')); ?>?search='+$('search').val())"
                                class="btn btn-primary">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <table class="table">
        <thead>
            <tr>
                <th width="60px">No.</th>
                <th>Title Posts</th>
                <?php echo e(request()->session()->get('field')=='title'?(request()->session()->get('sort')=='asc'?'&#9652;':'&#9662;'):''); ?>

                <th>Description</th>
                <?php echo e(request()->session()->get('field')=='title'?(request()->session()->get('sort')=='asc'?'&#9652;':'&#9662;'):''); ?>

                <th>Created At</th>
                <th>Updated At</th>
                <th>
                    <a href="javascript:ajaxLoad('<?php echo e(url('posts/create')); ?>')" class="btn btn-xs btn-primary"><i class="glyphicon glyphicon-plus"></i> New Post</a>
                </th>
            </tr>
        </thead>
        <tbody>
            <?php
                $i = 1;
            ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($value->title); ?></td>
                    <td><?php echo e($value->description); ?></td>
                    <td><?php echo e($value->created_at); ?></td>
                    <td><?php echo e($value->updated_at); ?></td>
                    <td>
                        <a href="javascript:ajaxLoad('<?php echo e(url('posts/show/'.$value->id)); ?>')" class="btn btn-xs btn-info">Show</a>
                        <a href="javascript:ajaxLoad('<?php echo e(url('posts/update/'.$value->id)); ?>')" class="btn btn-xs btn-warning">Edit</a>
                        <input type="hidden" name="_method" value="delete"/>
                        <a href="javascript:if(confirm('Are you sure to delete this data?')) ajaxDelete('<?php echo e(url('posts/deletePost/'.$value->id)); ?>','<?php echo e(csrf_token()); ?>')" class="btn btn-xs btn-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <ul class="pagination">
        <?php echo e($posts->links()); ?>

    </ul>
</div>