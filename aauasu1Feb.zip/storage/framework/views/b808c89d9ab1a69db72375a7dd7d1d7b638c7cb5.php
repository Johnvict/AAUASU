<title>My Private Conversation</title>
<?php $__env->startSection('content'); ?>
    <style>
        a, a:active, a:hover {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
    </style>

    <div class="container">
        <div class="row">
            <div class="col col-md-6">
                <div class="row">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <button class="btn btn-primary btn-sm"><a href="<?php echo e(route('newPchat')); ?>">Start New Chat</a></button>
                        </div>
                        <div class="panel-body">

                            <div>
                                <?php if(session('users') != null): ?>
                                    <div class="alert alert-warning">
                                        <div cla ss="col col-md-6">
                                            <?php if(count($users)>0): ?>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(Auth::user() == $user): ?>
                                                        <?php continue; ?>
                                                    <?php else: ?>
                                                        <form method="POST" action="<?php echo e(route('newConversation')); ?>">
                                                            <?php echo e(csrf_field()); ?>

                                                            <input type="hidden" name="hisId" value="<?php echo e($user->id); ?>">
                                                            <input type="hidden" name="myId" value="<?php echo e(Auth::user()->id); ?>">
                                                            <input type="hidden" name="conversationId" value="<?php echo e(Auth::user()->id); ?>-<?php echo e($user->id); ?>">
                                                            <button clas="btn btn-success" type="submit"><span class="glyphicon glyphicon-chat">
                                                            <?php if($user->Avatar == 'AvatarDefault'.$user->Gender.'.jpg'): ?>
                                                                        <img class="imag col-md-offset-6" src="/avatar/<?php echo e($user->Avatar); ?>"alt="" style="width:35px">
                                                                    <?php else: ?>
                                                                        <img class="imag col-md-offset-6" src="<?php echo e($user->Avatar); ?>" alt="" style="width:35px">
                                                                    <?php endif; ?>
                                                                    <a style="color: dodgerblue; font-family: algerian; font-size: 1.2em;"><b><?php echo e($user->Username); ?>

                                                                        </b></a></span>
                                                            </button>
                                                        </form>
                                                        This: <?php echo e($user->id); ?>, Mine:<?php echo e(Auth::user()->id); ?>

                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <div class="alert alert-warning">
                                                    <p>Sorry! You have no Buddy on your Buddy List </p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>


                            <div>
                                <?php if(count($myChats)>0): ?>
                                    <?php $__currentLoopData = $chatters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $chatter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatterAtt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div>
                                                <div class="alert alert-success">
                                                    <a href="/conversation/<?php echo e(Auth::user()->id); ?>-<?php echo e($chatterAtt->user_UserId); ?>">
                                                        <button  clas="btn btn-success" type="button"><span class="glyphicon glyphicon-chat">
                                                                        <?php if($chatterAtt->Avatar == 'AvatarDefault'.$chatterAtt->Gender.'.jpg'): ?>
                                                                <img class="imag col-md-offset-6" src="/avatar/<?php echo e($chatterAtt->Avatar); ?>"alt="" style="width:35px">
                                                            <?php else: ?>
                                                                <img class="imag col-md-offset-6" src="<?php echo e($chatterAtt->Avatar); ?>" alt="" style="width:35px">
                                                            <?php endif; ?>
                                                            <a style="color: dodgerblue; font-family: algerian; font-size: 1.2em;"><b><?php echo e($chatterAtt->Username); ?>

                                                                </b></a></span>
                                                        </button>
                                                    </a>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="alert alert-warning">
                                        <b>Click on the above button to start a new chat</b>
                                    </div>
                                <?php endif; ?>
                            </div>


                        </div>
                    </div>

                </div>
            </div>
            <div class="col col-md-3">
                Thhis should be quick links or adverts
            </div>
            <div class="col col-md-3">
                Thhis should be quick links or adverts
                Thhis should be quick links or adverts
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.aauaites', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>