  

<title>Past Administration</title>
<?php $__env->startSection('content'); ?>
<h2>Past Administrations</h2>

  <div class="div">
   <p>Past Administration of the Students Union</p>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>