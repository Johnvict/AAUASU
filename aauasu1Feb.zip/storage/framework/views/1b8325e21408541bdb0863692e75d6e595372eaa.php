<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel AJAX CRUD Example</title>
    <?php echo $__env->yieldContent('head'); ?>
    <link rel="stylesheet" type="text/css" href=<?php echo e(url('css/app.css')); ?>>
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <nav class="navbar fixed-top bg-info">
        <a href="/posts">Laravel Video Tutorials</a>
        <?php echo $__env->yieldContent('nav'); ?>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>