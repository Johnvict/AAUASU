<?php if(auth()->guard()->guest()): ?>

    <br><br>
<div class="panel panel-primary">
<div class="panel-heading text-center"><h1>Error Occured!</h1></div>

    <div class="panel-body">
        <div class="container alert alert-info">
            <h2 class ="text-center">Ooops!<br>Sign Up or Login to access all resources as a registered user</h2><br>
            <a class="btn btn-primary col-md-offset-5" href="/"><b>Register/Login Here</b></a>

            <br><br><br>
        </div>
    </div>
</div>

    <?php echo e(die()); ?>


<?php else: ?>
  <style>
      .navbar-logo {
          background-image: url('/images/sulogo33.png');
          width:220px;
          height:50px;
      }

      .navbar-logo:hover {
          background-image: url('/images/aauasu.png');
          width:220px;
          height:50px;
      }

    .navbar-left {
        width:220px;
        height:50px;
        border-radius: 10px;
    }
      h1{
          color: white;
          font-family: "Lucida Handwriting"
      }

    .navbar-logo {
        width:220px;
        height:50px;
    }
    .navbar-right {
        margin-right: 5px;
    }
</style>

  <?php if(Auth::user()->is_admin == "1"): ?>
      <?php echo $__env->make('includes.adminNav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php else: ?>

      <div>
          <nav class="navbar navbar-inverse">
              <div class="container-fluid">
                  <ul class="nav navbar-nav">
                      <a href="/"><img class="navbar-nav navbar-left navbar-logo"></a>
                      <li class=""><a href='<?php echo url('/aauaites/home'); ?>'>Home</a></li>
                      <li class=""><a href="/profile/<?php echo e(Auth::user()->Username); ?>">My Profile</a></li>
                      
                      <li><a href="<?php echo e(route('materials')); ?>">Materials</a></li>
                      <li><a href="<?php echo e(route('courses')); ?>">My Courses</a></li>
                      <li><a href="<?php echo e(route('gradepoint')); ?>">My Grade Point</a></li>
                      
                      
                  </ul>
                  <ul class="nav navbar-nav navbar-right">
                      <li><a href="<?php echo e(route('logout')); ?>"><h><span class="glyphicon glyphicon-log-out"></span><b> Logout <?php echo e(Auth::user()->Username); ?></b></h></a></li>
                  </ul>
              </div>
          </nav>
      </div>
  <?php endif; ?>

<?php endif; ?>